package com.scalablescripts.auth.dtos

class Message(public val message: String) {
}