package com.scalablescripts.auth.query

import com.expediagroup.graphql.spring.operations.Query
import com.scalablescripts.auth.models.User
import com.scalablescripts.auth.repositories.UserRepository
import org.springframework.stereotype.Component

@Component
class UserQuery(private val repository: UserRepository) : Query {

    fun users(): List<User> {
        return repository.findAll()
    }

    fun user(email: String): User? {
        return repository.findByEmail(email)
    }
}