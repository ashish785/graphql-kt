package com.scalablescripts.auth.mutation

import com.expediagroup.graphql.spring.operations.Mutation

class UserMutation : Mutation{

}