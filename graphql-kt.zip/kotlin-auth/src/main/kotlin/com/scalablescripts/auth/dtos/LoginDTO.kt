package com.scalablescripts.auth.dtos

class LoginDTO {
    val email = ""
    val password = ""
}