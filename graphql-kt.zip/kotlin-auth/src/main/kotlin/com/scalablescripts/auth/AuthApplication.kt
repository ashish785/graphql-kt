package com.scalablescripts.auth

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import com.scalablescripts.auth.models.User
import com.scalablescripts.auth.repositories.UserRepository
import org.slf4j.LoggerFactory
import org.springframework.boot.CommandLineRunner
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.util.ResourceUtils
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream


@Configuration
@EnableAutoConfiguration(exclude = [SecurityAutoConfiguration::class])
@ComponentScan("com.scalablescripts.auth")
class AuthApplication (private val userRepository: UserRepository): CommandLineRunner {
    private val log = LoggerFactory.getLogger(AuthApplication::class.java)

    override fun run(vararg args: String?) {
        println("runnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn Saved!")

        val mapper = ObjectMapper()
        val typeReference: TypeReference<List<User>?> = object : TypeReference<List<User>?>() {}
        val file: File = ResourceUtils.getFile("classpath:users.json")
        val inputStream: InputStream = FileInputStream(file)
        try {
            val users: List<User>? = mapper.readValue(inputStream, typeReference)
            if (users != null) {
                for(user in users){
                    userRepository.save(user);
                }
            }
            println("Users Saved!")
        } catch (e: IOException) {
            println("Unable to save users: " + e.message)
        }
    }
}

fun main(args: Array<String>) {
    runApplication<AuthApplication>(*args)
}

@Bean
fun runner(userRepository: UserRepository): CommandLineRunner {
    return CommandLineRunner { args: Array<String?>? ->
        // read json and write to db
        val mapper = ObjectMapper()
        val typeReference: TypeReference<List<User>?> = object : TypeReference<List<User>?>() {}
        val inputStream: InputStream = TypeReference::class.java.getResourceAsStream("users.json")
        try {
            val users: List<User>? = mapper.readValue(inputStream, typeReference)
            if (users != null) {
                for(user in users){
                    userRepository.save(user);
                }
            }
            println("Users Saved!")
        } catch (e: IOException) {
            println("Unable to save users: " + e.message)
        }
    }
}