package com.scalablescripts.auth.dtos

class RegisterDTO {
    val firstName = ""
    val email = ""
    val password = ""
}