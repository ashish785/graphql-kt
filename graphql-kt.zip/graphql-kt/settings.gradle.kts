rootProject.name = "graphql-kt"
