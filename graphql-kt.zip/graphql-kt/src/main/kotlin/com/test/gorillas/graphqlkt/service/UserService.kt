package com.test.gorillas.graphqlkt.service

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.test.gorillas.graphqlkt.model.User
import com.test.gorillas.graphqlkt.repository.UserRepository
import org.springframework.core.io.ClassPathResource
import org.springframework.core.io.Resource
import org.springframework.stereotype.Service
import java.io.BufferedReader
import java.io.InputStreamReader


@Service
class UserService {
    val dataFile : String = "users.json";
    fun findAll(): List<User> {
        return getAllUsers();
    }
    fun findUserByEmail(email: String): User? = readJSONfromFile(dataFile).find { email == it.email }

    fun getAllUsers() : List<User> {
        //return UserRepository().findAll().toList();
        return readJSONfromFile(dataFile)
    }

    private fun readJSONfromFile(f:String): List<User> {
        //Read the users.json file
        val resource: Resource = ClassPathResource(f)
        val bufferedReader: BufferedReader =  BufferedReader( InputStreamReader(resource.getInputStream()))
        // Read the text from buffferReader and store in String variable
        val inputString = bufferedReader.use { it.readText() }
        val mapper = jacksonObjectMapper();
        val userListFromJson: List<User> = mapper.readValue(inputString)
        println("Users are ")
        println(userListFromJson)
        return userListFromJson
    }
}