package com.test.gorillas.graphqlkt

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import com.test.gorillas.graphqlkt.model.User
import com.test.gorillas.graphqlkt.repository.UserRepository
import org.springframework.boot.CommandLineRunner
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration
import java.io.IOException
import java.io.InputStream


@EnableAutoConfiguration
@Configuration
@ComponentScan ("com.test.gorillas.graphqlkt")
class GraphqlKtApplication

fun main(args: Array<String>) {
	runApplication<GraphqlKtApplication>(*args)
}

@Bean
fun runner(userRepository: UserRepository): CommandLineRunner {
	return CommandLineRunner { args: Array<String?>? ->
		// read json and write to db
		val mapper = ObjectMapper()
		val typeReference: TypeReference<List<User>?> = object : TypeReference<List<User>?>() {}
		val inputStream: InputStream = TypeReference::class.java.getResourceAsStream("users.json")
		try {
			val users: List<User>? = mapper.readValue(inputStream, typeReference)
			if (users != null) {
				for(user in users){
					userRepository.save(user);
				}
			}
			println("Users Saved!")
		} catch (e: IOException) {
			println("Unable to save users: " + e.message)
		}
	}
}