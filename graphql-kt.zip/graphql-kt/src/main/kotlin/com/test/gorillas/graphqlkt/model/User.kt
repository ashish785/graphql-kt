package com.test.gorillas.graphqlkt.model

import javax.persistence.Entity
import javax.persistence.Id

@Entity
data class User(
    @Id
    var email : String= "",
    var  firstName : String = "",
    var  lastName : String="",
    var  password : String="",
    var  userName : String=""

)