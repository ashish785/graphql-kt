package com.test.gorillas.graphqlkt.mutation

import com.expediagroup.graphql.annotations.GraphQLDescription
import com.expediagroup.graphql.spring.operations.Mutation
import com.test.gorillas.graphqlkt.model.User
import com.test.gorillas.graphqlkt.repository.UserRepository

class UserMutation(private val userRepository: UserRepository) : Mutation{

        @GraphQLDescription("Logs in user and returns JWT")
        fun login(email: String, password: String) : String? {
              val user =  userRepository.findUserByEmail(email);
               return user?.password;
        }
}