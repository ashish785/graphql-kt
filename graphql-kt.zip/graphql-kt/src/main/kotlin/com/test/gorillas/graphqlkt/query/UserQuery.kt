package com.test.gorillas.graphqlkt.query

import org.springframework.stereotype.Component
import com.expediagroup.graphql.spring.operations.Query
import com.test.gorillas.graphqlkt.model.User
import com.test.gorillas.graphqlkt.service.UserService

@Component
class UserQuery(private val service: UserService) : Query {

    fun users(): List<User> {
        return service.findAll()
    }

    fun user(email: String): User? {
        return service.findUserByEmail(email);
    }
}