package com.test.gorillas.graphqlkt.repository;

import com.test.gorillas.graphqlkt.model.User
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface UserRepository : JpaRepository<User, String>
{
    fun findUserByEmail(email: String) : User?

}
