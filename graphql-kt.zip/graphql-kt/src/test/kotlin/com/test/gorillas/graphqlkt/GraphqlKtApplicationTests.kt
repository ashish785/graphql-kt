package com.test.gorillas.graphqlkt

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GraphqlKtApplicationTests {

	@Test
	fun contextLoads() {
	}

}
